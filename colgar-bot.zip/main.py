from fastapi import FastAPI
from fastapi.responses import Response

app = FastAPI()

@app.get("/finalizar_llamada")
async def finalizar_llamada():
    twiml = """
    <Response>
      <Say voice="alice" language="es-ES">Gracias por su tiempo. Hasta luego.</Say>
      <Hangup/>
    </Response>
    """
    return Response(content=twiml, media_type="application/xml")
